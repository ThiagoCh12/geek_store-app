﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using geekstore.Classes;

namespace geekstore
{
    public partial class FrmProduto : Form
    {
        public FrmProduto()
        {
            InitializeComponent();
        }
        public void CarregaCbxTipo()
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Downloads\\geekstore\\geekstore\\DbBoteco.mdf;Integrated Security=True");
            string sql = "SELECT * FROM Tipo";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Tipo");
            cbxTipo.ValueMember = "tipo";
            cbxTipo.DisplayMember = "tipo";
            cbxTipo.DataSource = ds.Tables["Tipo"];
            con.Close();
        }

        private void FrmProduto_Load(object sender, EventArgs e)
        {
            CarregaCbxTipo();
            Produto produto = new Produto();
            List<Produto> produtos = produto.listaproduto();
            dgvProduto.DataSource = produtos;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }
        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNome.Text == "" && txtValor.Text == "" && txtQuantidade.Text == "")
                {
                    MessageBox.Show("Por favor, preencha todos os campos!", "Campos obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    Produto produto = new Produto();
                    if (produto.RegistroRepetido(txtNome.Text, cbxTipo.Text) == true)
                    {
                        MessageBox.Show("Produto já existe em nossa base de dados!", "Repetido", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtNome.Text = "";
                        txtValor.Text = "";
                        txtQuantidade.Text = "";
                        cbxTipo.Text = "";
                        this.ActiveControl = txtNome;
                    }
                    else
                    {
                        int qtde = Convert.ToInt32(txtQuantidade.Text.Trim());
                        if (qtde == 0)
                        {
                            MessageBox.Show("A quantidade não pode ser igual a zero.", "Quantidade", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.ActiveControl = txtQuantidade;
                            return;
                        }
                        else
                        {
                            produto.Inserir(txtNome.Text, cbxTipo.Text, qtde, txtValor.Text);
                            MessageBox.Show("Produto inserido com sucesso!", "Inserção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtNome.Text = "";
                            txtQuantidade.Text = "";
                            txtValor.Text = "";
                            cbxTipo.Text = "";
                            this.ActiveControl = txtNome;
                            List<Produto> produtos = produto.listaproduto();
                            dgvProduto.DataSource = produtos;
                        }
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtId.Text.Trim() == "")
                {
                    MessageBox.Show("Por favor digite o ID para localizar o produto!", "Localizar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    Produto produto = new Produto();
                    int Id = Convert.ToInt32(txtId.Text.Trim());
                    produto.Localizar(Id);
                    txtNome.Text = produto.nome;
                    cbxTipo.Text = produto.tipo;
                    txtQuantidade.Text = Convert.ToString(produto.quantidade);
                    txtValor.Text = Convert.ToString(produto.valor);
                    btnEditar.Enabled = true;
                    btnExcluir.Enabled = true;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Localização", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




    }
}
