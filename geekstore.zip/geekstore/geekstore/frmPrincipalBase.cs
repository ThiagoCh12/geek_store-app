﻿namespace geekstore
{
    internal partial class FrmPrincipal
    {

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FrmPrincipal
            // 
            this.ClientSize = new System.Drawing.Size(317, 261);
            this.Name = "FrmPrincipal";
            this.ResumeLayout(false);

        }
    }
}